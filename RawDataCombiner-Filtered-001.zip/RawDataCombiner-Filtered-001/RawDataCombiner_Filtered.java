import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;

public class RawDataCombiner_Filtered {

    // Mapper for title.basics.tsv
    public static class BasicsMapper extends Mapper<Object, Text, Text, Text> {
        private Text tconstKey = new Text();
        private Text dataValue = new Text();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            if (line.startsWith("tconst")) { // Skip header row
                return;
            }

            String[] fields = line.split("\t", -1);
            tconstKey.set(fields[0]);
            dataValue.set("BASICS:" + line);
            context.write(tconstKey, dataValue);
        }
    }

    // Mapper for title.ratings.tsv
    public static class RatingsMapper extends Mapper<Object, Text, Text, Text> {
        private Text tconstKey = new Text();
        private Text dataValue = new Text();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            if (line.startsWith("tconst")) { // Skip header row
                return;
            }

            String[] fields = line.split("\t", -1);
            tconstKey.set(fields[0]);
            dataValue.set("RATINGS:" + line);
            context.write(tconstKey, dataValue);
        }
    }

    // Mapper for title.crew.tsv
    public static class CrewMapper extends Mapper<Object, Text, Text, Text> {
        private Text tconstKey = new Text();
        private Text dataValue = new Text();

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();
            if (line.startsWith("tconst")) { // Skip header row
                return;
            }

            String[] fields = line.split("\t", -1);
            tconstKey.set(fields[0]);
            dataValue.set("CREW:" + line);
            context.write(tconstKey, dataValue);
        }
    }

    // Reducer
    public static class JoinReducer extends Reducer<Text, Text, Text, Text> {
        private static final Logger logger = Logger.getLogger(JoinReducer.class);
        private Text result = new Text();
        private static boolean headerWritten = false; // Flag to ensure the header is written only once
    
        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            // Write the header line only once, before processing any records
            if (!headerWritten) {
                String header = "tconst\t" +
                                "titleType\tprimaryTitle\tstartYear\truntimeMinutes\tgenres\t" +
                                "averageRating\tnumVotes\t" +
                                "directors\twriters";
                context.write(null, new Text(header)); // Write header line without a key to avoid stray tab
                headerWritten = true;
            }
        }
    
        public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
            String basics = null;
            String ratings = null;
            String crew = null;
        
            // Sort values into their respective datasets
            for (Text value : values) {
                String data = value.toString();
                if (data.startsWith("BASICS:")) {
                    basics = data.substring(7); // Remove "BASICS:"
                } else if (data.startsWith("RATINGS:")) {
                    ratings = data.substring(8); // Remove "RATINGS:"
                } else if (data.startsWith("CREW:")) {
                    crew = data.substring(5); // Remove "CREW:" 
                }
            }
        
            // Default missing values to \N placeholders
            if (basics != null && ratings != null) {
                String[] basicsFields = basics.split("\t", -1);
        
                // Make sure basics is a complete dataset
                if (basicsFields.length >= 9) {
                    // Exclude originalTitle (index 3), isAdult (index 4), and endYear (index 6)
                    String filteredBasics = basicsFields[1] + "\t" + basicsFields[2] + "\t" + basicsFields[5] + "\t" + basicsFields[7] + "\t" + basicsFields[8];
        
                    ratings = ratings.substring(ratings.indexOf('\t') + 1); // Exclude tconst from RATINGS
        
                    if (crew == null) {
                        crew = "\\N\t\\N"; // Default for 2 columns in CREW
                        logger.warn("tconst " + key.toString() + " is missing crew data");
                    } else {
                        crew = crew.substring(crew.indexOf('\t') + 1); // Exclude tconst from CREW
                    }
        
                    // Combine all parts
                    result.set(filteredBasics + "\t" + ratings + "\t" + crew);
                    context.write(key, result);
                } else {
                    logger.warn("tconst " + key.toString() + " in basics data has insufficient fields.");
                }
            } else {
                logger.warn("tconst " + key.toString() + " is missing data");
            }
        }

}


    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Join IMDb Data");
        job.setJarByClass(RawDataCombiner_Filtered.class);

        // Set up multiple inputs
        MultipleInputs.addInputPath(job, new Path(args[0]), TextInputFormat.class, BasicsMapper.class);
        MultipleInputs.addInputPath(job, new Path(args[1]), TextInputFormat.class, RatingsMapper.class);
        MultipleInputs.addInputPath(job, new Path(args[2]), TextInputFormat.class, CrewMapper.class);

        job.setReducerClass(JoinReducer.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileOutputFormat.setOutputPath(job, new Path(args[3]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
