Outputs a Graph showing the Average Rating over time as well as the Weight of the data points over time


MUST HAVES in Directory with jar and java files
part-r-00000 from GenreRevised Output renamed as data.csv
titleTypeMap-r-00000 from GenreRevised Output renamed titleTypeMap.txt
genreMap-r-00000 from GenreRevised Output renamed to genreMap.txt


Compile Using

javac -cp .:jfreechart-1.0.19.jar:jcommon-1.0.23.jar RatingVsYearPlot.java

Run Using

java -cp .:jfreechart-1.0.19.jar:jcommon-1.0.23.jar RatingVsYearPlot <titleTypeString> <genreString>