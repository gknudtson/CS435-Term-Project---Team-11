Finds director/writer pairings and associates thme with average ratings, total votes, and the amount of collaborations together
Input must be the output of RawDataCombiner_Filtered

Input Command: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Sample output: "nm0002988,nm2091375     avgRating=7.70,totalVotes=2121,collaborations=1"