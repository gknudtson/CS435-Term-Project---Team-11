Outputs highest weighted average vote for genre/director/writer combinations as well as their orignal metrics
Input must be the output of CollaborationAnalyzer

Input Command: Input Command: hadoop jar <jar_name> <.class of driver> <HDFSCollaborationOutputPath> <HDFSOutputPath>

Output Sample: "24.13   Drama/nm0400486/nm0319213       Original metrics: avgRating=9.13,totalVotes=2954108,collaborations=4,highestRating=9.5,lowestRating=8.7,yearSpan=2008-2020,duration=13  Factor scores: collaborationScore=0.64, voteScore=1.71, timeScore=0.20, consistencyScore=0.09,"