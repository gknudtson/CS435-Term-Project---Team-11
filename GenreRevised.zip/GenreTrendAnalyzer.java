import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.MultipleOutputs;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GenreTrendAnalyzer {
    private static final Logger logger = Logger.getLogger(GenreTrendAnalyzer.class);

    public static class GenreTrendMapper extends Mapper<Object, Text, Text, Text> {
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] fields = value.toString().split("\t");
            if (fields.length < 8 || fields[0].equals("tconst")) {
                return;
            }

            String year = fields[3];
            String genres = fields[5];
            String rating = fields[6];
            String votes = fields[7];

            if (!year.equals("\\N") && !genres.equals("\\N")) {
                try {
                    String[] genreList = genres.split(",");
                    List<String> combinations = getCombinations(genreList);
                    
                    for (String combination : combinations) {
                        String titleType = fields[1];
                        context.write(
                            new Text(String.format("%s_%s_%s", year, titleType.trim(), combination.trim())),
                            new Text(rating + "_" + votes)
                        );
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid year format in line: " + value.toString());
                }
            }
        }

        private List<String> getCombinations(String[] genres) {
            List<String> combinations = new ArrayList<>();
            int n = genres.length - 1;
            // Generate all non-empty combinations of genres
            for (int i = 0; i < n; i++) {
                combinations.add(genres[i]);
            }
                return combinations;
        }
    }

    public static class GenreTrendReducer extends Reducer<Text, Text, NullWritable, Text> {
        private MultipleOutputs<NullWritable, Text> mos;
        private Map<String, Integer> titleTypeMap = new HashMap<>();
        private Map<String, Integer> genreMap = new HashMap<>();
        private int titleTypeCounter = 1;
        private int genreCounter = 1;

        @Override
        protected void setup(Context context) throws IOException, InterruptedException {
            mos = new MultipleOutputs<>(context);
        }

        public void reduce(Text key, Iterable<Text> values, Context context)
                throws IOException, InterruptedException {
            // Split the key into year, titleType, genre
            String[] keyParts = key.toString().split("_");
            if (keyParts.length != 3) {
                // Invalid key format
                return;
            }
            String year = keyParts[0];
            String titleType = keyParts[1];
            String genre = keyParts[2];

            // Map titleType to number
            int titleTypeNumber;
            if (titleTypeMap.containsKey(titleType)) {
                titleTypeNumber = titleTypeMap.get(titleType);
            } else {
                titleTypeNumber = titleTypeCounter++;
                titleTypeMap.put(titleType, titleTypeNumber);
            }

            // Map genre to number
            int genreNumber;
            if (genreMap.containsKey(genre)) {
                genreNumber = genreMap.get(genre);
            } else {
                genreNumber = genreCounter++;
                genreMap.put(genre, genreNumber);
            }

            // Compute weighted average rating using log-based weighting
            double totalWeightedRating = 0;
            double totalWeight = 0;
            int count = 0;

            for (Text val : values) {
                String[] parts = val.toString().split("_");
                try {
                    if (!parts[0].equals("\\N") && !parts[1].equals("\\N")) {
                        double rating = Double.parseDouble(parts[0]);
                        long votes = Long.parseLong(parts[1]);
                        double weight = Math.log(1 + votes);
                        totalWeightedRating += weight * rating;
                        totalWeight += weight;
                        count++;
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid number format in value: " + val.toString());
                }
            }

            if (count > 0 && totalWeight > 0) {
                double avgRating = totalWeightedRating / totalWeight;
                String result = String.format("%s,%d,%d,%.2f,%d,%d",
                    year, titleTypeNumber, genreNumber, avgRating, (long) totalWeight, count);
                context.write(NullWritable.get(), new Text(result));
            }
        }

        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException {
            // Write titleType mappings
            for (Map.Entry<String, Integer> entry : titleTypeMap.entrySet()) {
                mos.write("titleTypeMap", NullWritable.get(), new Text(entry.getKey() + "," + entry.getValue()));
            }
            // Write genre mappings
            for (Map.Entry<String, Integer> entry : genreMap.entrySet()) {
                mos.write("genreMap", NullWritable.get(), new Text(entry.getKey() + "," + entry.getValue()));
            }
            mos.close();
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: GenreTrendAnalyzer <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Genre Trend Analysis");
        job.setJarByClass(GenreTrendAnalyzer.class);

        job.setMapperClass(GenreTrendMapper.class);
        job.setReducerClass(GenreTrendReducer.class);

        // Set the map output key and value classes
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(Text.class);

        // Set the final output key and value classes
        job.setOutputKeyClass(NullWritable.class);
        job.setOutputValueClass(Text.class);

        // Set up MultipleOutputs
        MultipleOutputs.addNamedOutput(job, "titleTypeMap", TextOutputFormat.class, NullWritable.class, Text.class);
        MultipleOutputs.addNamedOutput(job, "genreMap", TextOutputFormat.class, NullWritable.class, Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}

