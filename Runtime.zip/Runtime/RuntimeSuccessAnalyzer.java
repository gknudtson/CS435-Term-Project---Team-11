import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;

public class RuntimeSuccessAnalyzer {
    private static final Logger logger = Logger.getLogger(RuntimeSuccessAnalyzer.class);

    public static class RuntimeSuccessMapper extends Mapper<Object, Text, Text, Text> {
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] fields = value.toString().split("\t");
            if (fields.length < 8 || fields[0].equals("tconst")) {
                return;
            }

            String runtime = fields[4];    // Runtime is in position 4
            String genres = fields[5];     // Genres is in position 5
            String rating = fields[6];     // Rating is in position 6
            String votes = fields[7];      // Votes is in position 7
            String titleType = fields[1];  // Title type is in position 1
            
            if (!runtime.equals("\\N")) {
                try {
                    int runtimeMinutes = Integer.parseInt(runtime);
                    // Group runtimes into 15-minute intervals
                    int runtimeGroup = (runtimeMinutes / 15) * 15;
                    
                    // Create runtime ranges for better grouping
                    String runtimeRange;
                    if (runtimeMinutes < 30) runtimeRange = "under30";
                    else if (runtimeMinutes < 60) runtimeRange = "30to60";
                    else if (runtimeMinutes < 90) runtimeRange = "60to90";
                    else if (runtimeMinutes < 120) runtimeRange = "90to120";
                    else if (runtimeMinutes < 150) runtimeRange = "120to150";
                    else runtimeRange = "over150";
                    
                    if (!genres.equals("\\N")) {
                        String[] genreList = genres.split(",");
                        for (String genre : genreList) {
                            // Create composite key for output
                            String compositeKey = String.format("%s/%s/%s", 
                                                     runtimeRange, 
                                                     titleType, 
                                                     genre.trim());
                            context.write(new Text(compositeKey), 
                                        new Text(rating + "," + votes + "," + runtimeMinutes));
                        }
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid runtime format in line: " + value.toString());
                }
            }
        }
    }

    public static class RuntimeSuccessReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> values, Context context) 
                throws IOException, InterruptedException {
            double totalRating = 0;
            int count = 0;
            long totalVotes = 0;
            int totalRuntime = 0;
            double weightedRatingSum = 0;
            long totalWeightedCount = 0;

            for (Text val : values) {
                String[] parts = val.toString().split(",");
                try {
                    if (!parts[0].equals("\\N") && !parts[1].equals("\\N")) {
                        double rating = Double.parseDouble(parts[0]);
                        long votes = Long.parseLong(parts[1]);
                        int runtime = Integer.parseInt(parts[2]);
                        
                        weightedRatingSum += rating * votes;
                        totalWeightedCount += votes;
                        
                        totalRating += rating;
                        totalVotes += votes;
                        totalRuntime += runtime;
                        count++;
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid number format in value: " + val.toString());
                }
            }

            if (count > 0) {
                double avgRating = totalRating / count;
                double avgRuntime = (double) totalRuntime / count;
                double weightedAvgRating = weightedRatingSum / totalWeightedCount;
                
                String result = String.format(
                    "avgRating=%.2f,weightedAvgRating=%.2f,avgRuntime=%.1f,totalVotes=%d,count=%d",
                    avgRating, weightedAvgRating, avgRuntime, totalVotes, count
                );
                context.write(key, new Text(result));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: RuntimeSuccessAnalyzer <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Runtime Success Analysis");
        job.setJarByClass(RuntimeSuccessAnalyzer.class);

        job.setMapperClass(RuntimeSuccessMapper.class);
        job.setReducerClass(RuntimeSuccessReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}