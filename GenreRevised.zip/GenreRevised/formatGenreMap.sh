sed -E 's/,([^,]*$)/;\1/; s/,/_/g; s/;/,/' OutputData/genreMap-r-00000 > OutputData/genreMap
