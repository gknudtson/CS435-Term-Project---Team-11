import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;

public class CollaborationAnalyzer {
    private static final Logger logger = Logger.getLogger(CollaborationAnalyzer.class);

    public static class CollaborationMapper extends Mapper<Object, Text, Text, Text> {
        private static final int MIN_VOTES = 40;

        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] fields = value.toString().split("\t");
            if (fields.length < 10 || fields[0].equals("tconst")) {
                return;
            }

            String directors = fields[8];
            String writers = fields[9];
            String rating = fields[6];
            String votes = fields[7];
            String genres = fields[5];
            
            try {
                if (!votes.equals("\\N") && Integer.parseInt(votes) > MIN_VOTES) {
                    if (!directors.equals("\\N") && !writers.equals("\\N") && !genres.equals("\\N")) {
                        String[] directorList = directors.split(",");
                        String[] writerList = writers.split(",");
                        String[] genreList = genres.split(",");
                        
                        for (String director : directorList) {
                            for (String writer : writerList) {
                                if (!director.equals(writer)) {
                                    for (String genre : genreList) {
                                        String compositeKey = String.format("%s/%s/%s", 
                                            genre.trim(),
                                            director.trim(),
                                            writer.trim()
                                        );
                                        
                                        String compositeValue = String.format("%s,%s,%s", 
                                            rating,
                                            votes,
                                            fields[3]
                                        );
                                        
                                        context.write(new Text(compositeKey), new Text(compositeValue));
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (NumberFormatException e) {
                //Don't uncomment unless for debugging, outputs thousands of lines
                //logger.warn("Invalid number format in line: " + value.toString());
            }
        }
    }

    public static class CollaborationReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> values, Context context) 
                throws IOException, InterruptedException {
            double totalRating = 0;
            int count = 0;
            long totalVotes = 0;
            int earliestYear = Integer.MAX_VALUE;
            int latestYear = Integer.MIN_VALUE;
            double highestRating = 0;
            double lowestRating = 10.0;

            for (Text val : values) {
                String[] parts = val.toString().split(",");
                try {
                    double rating = Double.parseDouble(parts[0]);
                    long votes = Long.parseLong(parts[1]);
                    int year = Integer.parseInt(parts[2]);
                    
                    totalRating += rating;
                    totalVotes += votes;
                    count++;

                    highestRating = Math.max(highestRating, rating);
                    lowestRating = Math.min(lowestRating, rating);

                    earliestYear = Math.min(earliestYear, year);
                    latestYear = Math.max(latestYear, year);
                    
                } catch (NumberFormatException e) {
                    //Don't uncomment unless debugging as well
                    //logger.warn("Invalid number format in value: " + val.toString());
                }
            }

            if (count > 0) {
                double avgRating = totalRating / count;
                int collaborationSpan = latestYear - earliestYear + 1;
                
                String result = String.format(
                    "avgRating=%.2f,totalVotes=%d,collaborations=%d," +
                    "highestRating=%.1f,lowestRating=%.1f," +
                    "yearSpan=%d-%d,duration=%d",
                    avgRating, totalVotes, count,
                    highestRating, lowestRating,
                    earliestYear, latestYear, collaborationSpan
                );
                
                context.write(key, new Text(result));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: CollaborationAnalyzer <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Collaboration Analysis");
        job.setJarByClass(CollaborationAnalyzer.class);

        job.setMapperClass(CollaborationMapper.class);
        job.setReducerClass(CollaborationReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}