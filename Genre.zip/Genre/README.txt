Finds Genre by decade and associates with average rating, weighted average rating, total votes, and occurances of the genre within the decade
Input must be the output of RawDataCombiner_Filtered

Input Command: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Sample Output: "2020_tvEpisode_Horror   avgRating=7.42,weightedAvgRating=7.61,totalVotes=2280536,count=4143"