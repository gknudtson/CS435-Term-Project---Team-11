import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;

public class GenreTrendAnalyzer {
    private static final Logger logger = Logger.getLogger(GenreTrendAnalyzer.class);

    public static class GenreTrendMapper extends Mapper<Object, Text, Text, Text> {
        public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
            String[] fields = value.toString().split("\t");
            if (fields.length < 8 || fields[0].equals("tconst")) {
                return;
            }

            String year = fields[3]; 
            String genres = fields[5];
            String rating = fields[6];
            String votes = fields[7]; 
            
            if (!year.equals("\\N") && !genres.equals("\\N")) {
                try {
                    String[] genreList = genres.split(",");
                    int decade = (Integer.parseInt(year) / 10) * 10;
                    
                    for (String genre : genreList) {
                        String titleType = fields[1];
                        context.write(
                            new Text(String.format("%d_%s_%s", decade, titleType, genre.trim())),
                            new Text(rating + "," + votes)
                        );
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid year format in line: " + value.toString());
                }
            }
        }
    }

    public static class GenreTrendReducer extends Reducer<Text, Text, Text, Text> {
        public void reduce(Text key, Iterable<Text> values, Context context) 
                throws IOException, InterruptedException {
            double totalRating = 0;
            int count = 0;
            long totalVotes = 0;
            double weightedRatingSum = 0;
            long totalWeightedCount = 0;

            for (Text val : values) {
                String[] parts = val.toString().split(",");
                try {
                    if (!parts[0].equals("\\N") && !parts[1].equals("\\N")) {
                        double rating = Double.parseDouble(parts[0]);
                        long votes = Long.parseLong(parts[1]);
                        
                        // Calculate weighted rating based on number of votes
                        weightedRatingSum += rating * votes;
                        totalWeightedCount += votes;
                        
                        totalRating += rating;
                        totalVotes += votes;
                        count++;
                    }
                } catch (NumberFormatException e) {
                    logger.warn("Invalid number format in value: " + val.toString());
                }
            }

            if (count > 0) {
                double avgRating = totalRating / count;
                double weightedAvgRating = weightedRatingSum / totalWeightedCount;
                String result = String.format(
                    "avgRating=%.2f,weightedAvgRating=%.2f,totalVotes=%d,count=%d",
                    avgRating, weightedAvgRating, totalVotes, count
                );
                context.write(key, new Text(result));
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: GenreTrendAnalyzer <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Genre Trend Analysis");
        job.setJarByClass(GenreTrendAnalyzer.class);

        job.setMapperClass(GenreTrendMapper.class);
        job.setReducerClass(GenreTrendReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}