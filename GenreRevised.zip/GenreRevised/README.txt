Finds Genre by year and title type and associates with weighted average rating, total votes, and total count of contributions

Input must be the output of RawDataCombiner_Filtered

Input Command: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Outputs 3 Files, titleTypeMap-r-00000, genreMap-r-00000, part-r-00000

After running move the output files into a directory in the same directory the .java file is called OutputData then run formatGenreMap.sh

This is needed because the output of genreMap-r-00000 is comma seperated so that they can be matched to the Comma seperated data in the filtered data input,
but they cannot be comma seperated for the genre predictor or else it will error out

so formatGenreMap.sh replaces all the non last commas with "_"s

My Copy Paste for Compiling and Running

javac -classpath `hadoop classpath` *.java
hdfs dfs -rm -r <HDFSOutputDirectory>
jar cvf run.jar *
hadoop jar run.jar GenreTrendAnalyzer <HDFSInputDirectory> <HDFSOutputDirectory>
hdfs dfs -get <HDFSOutputDirectory>/* ~/Project/GenreRevised/OutputData/
                                             ^ *Location of .java and jarfile*