Finds Genre by year and title type and associates with weighted average rating, total votes, and total count of contributions

Input must be the output of RawDataCombiner_Filtered

Command to Run: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Outputs 3 Files, titleTypeMap-r-00000, genreMap-r-00000, part-r-00000
