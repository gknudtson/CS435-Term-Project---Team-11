Suggested to write to log file because there are lots of WARN outputs for the millions of lines that dont have sufficient data

hadoop jar <JarFile> RawDataCombiner_Filtered <HDFSInputPath>/title.basics.tsv <HDFSInputPath>/title.ratings.tsv <HDFSInputPath>/title.crew.tsv <HDFSOutputPath> job_output.log 2>&1
