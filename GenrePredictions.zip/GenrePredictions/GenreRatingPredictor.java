import weka.classifiers.trees.RandomForest;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Attribute;
import weka.core.DenseInstance;

import java.io.*;
import java.util.*;

public class GenreRatingPredictor {

    public static void main(String[] args) throws Exception {
        // Step 1: Load and preprocess the data
        Instances data = loadData("data.csv");

        // Set the class index to the AvgRating attribute
        data.setClassIndex(data.attribute("AvgRating").index());

        // Step 2: Train the Random Forest model
        RandomForest rf = new RandomForest();
        rf.buildClassifier(data);

        // Step 3: Prepare data for 2025 predictions
        Instances data2025 = create2025Data(data);

        // Step 4: Make predictions for 2025
        List<PredictionResult> predictions = makePredictions(rf, data2025);

        // Step 5: Load mapping files
        Map<Integer, String> titleTypeMap = loadCategoryMap("titleTypeMap.txt");
        Map<Integer, String> genreMap = loadCategoryMap("genreMap.txt");

        // Step 6: Determine the highest-rated genre per title type
        Map<Integer, PredictionResult> highestRatedGenres = findHighestRatedGenres(predictions);

        // Step 7: Display results
        displayResults(highestRatedGenres, titleTypeMap, genreMap);
    }

    // Step 1: Load, preprocess, and weight the data**
    // Method to load data from CSV file and apply instance weighting
    public static Instances loadData(String filename) throws Exception {
        // **Define attributes as numeric**
        ArrayList<Attribute> attributes = new ArrayList<>();
        attributes.add(new Attribute("Year"));                       
        attributes.add(new Attribute("TitleTypeCategoryNumber"));   
        attributes.add(new Attribute("GenreCategoryNumber"));      
        attributes.add(new Attribute("AvgRating"));                 

        // Create Instances object with the defined attributes
        Instances data = new Instances("GenreRatings", attributes, 0);

        // Read CSV file
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        int lineIndex = 0;

        while ((line = br.readLine()) != null) {
            // Split each line into parts
            String[] parts = line.split(",");
            if (parts.length < attributes.size() + 2) { // Expecting at least Year, TitleTypeCategoryNumber, GenreCategoryNumber, AvgRating, totalVotes, count
                System.err.println("Invalid data format in line: " + line);
                continue; // **Skip lines that don't have the correct number of fields**
            }

            double[] vals = new double[data.numAttributes()];
            try {
                // Parse the necessary parts into a double and store it in the vals array
                for (int i = 0; i < vals.length; i++) {
                    vals[i] = Double.parseDouble(parts[i]);
                }
                // Create a new instance with the parsed values
                Instance instance = new DenseInstance(1.0, vals);

                // Apply logarithmic weighting based on totalVotes and count
                double totalVotes = Double.parseDouble(parts[parts.length - 2]);
                double count = Double.parseDouble(parts[parts.length - 1]);
                double voteWeight = Math.log(1 + totalVotes);
                double countWeight = Math.log(1 + count);
                double weight = voteWeight * countWeight;
                instance.setWeight(weight);

                // Add the instance to the data
                data.add(instance);
                lineIndex++;
            } catch (NumberFormatException e) {
                System.err.println("Invalid number format in line: " + line);
                // Skip lines with invalid number formats
            }
        }
        br.close();

        return data; // Return the loaded, preprocessed, and weighted data
    }

    // Step 2: Prepare data for 2025 predictions
    // Method to create data instances for the year 2025
    public static Instances create2025Data(Instances template) throws Exception {
        // Collect unique TitleTypeCategoryNumbers and GenreCategoryNumbers from the existing data
        Set<Double> titleTypeNumbers = new HashSet<>();
        Set<Double> genreNumbers = new HashSet<>();

        // Iterate over the existing instances to gather information
        for (int i = 0; i < template.numInstances(); i++) {
            Instance inst = template.instance(i);
            titleTypeNumbers.add(inst.value(template.attribute("TitleTypeCategoryNumber")));
            genreNumbers.add(inst.value(template.attribute("GenreCategoryNumber")));
        }

        // Define attributes for the 2025 data
        ArrayList<Attribute> attributes = new ArrayList<>();
        attributes.add(new Attribute("Year"));
        attributes.add(new Attribute("TitleTypeCategoryNumber"));
        attributes.add(new Attribute("GenreCategoryNumber"));
        attributes.add(new Attribute("AvgRating")); // Class attribute

        // Create Instances object for 2025 data
        Instances data2025 = new Instances("Data2025", attributes, 0);
        data2025.setClassIndex(data2025.attribute("AvgRating").index());

        // Generate instances for all combinations of title types and genres
        for (Double titleTypeNumber : titleTypeNumbers) {
            for (Double genreNumber : genreNumbers) {
                double[] vals = new double[data2025.numAttributes()];
                vals[data2025.attribute("Year").index()] = 2025;
                vals[data2025.attribute("TitleTypeCategoryNumber").index()] = titleTypeNumber;
                vals[data2025.attribute("GenreCategoryNumber").index()] = genreNumber;
                vals[data2025.attribute("AvgRating").index()] = Double.NaN;     //Placeholder for prediction
                data2025.add(new DenseInstance(1.0, vals));
            }
        }

        return data2025; // Return the prepared data for 2025
    }

    // Step 3: Make predictions for 2025
    // Method to make predictions using the trained Random Forest model
    public static List<PredictionResult> makePredictions(RandomForest rf, Instances data2025) throws Exception {
        List<PredictionResult> predictions = new ArrayList<>();

        for (int i = 0; i < data2025.numInstances(); i++) {
            Instance inst = data2025.instance(i);
            double pred = rf.classifyInstance(inst); // Predict the AvgRating by passing Inst to Random Forest
            inst.setClassValue(pred); // Set the predicted value as the class value

            int titleTypeNumber = (int) inst.value(data2025.attribute("TitleTypeCategoryNumber"));
            int genreNumber = (int) inst.value(data2025.attribute("GenreCategoryNumber"));
            double predictedRating = pred;

            // Add the prediction result to the list
            predictions.add(new PredictionResult(titleTypeNumber, genreNumber, predictedRating));
        }

        return predictions; // Return the list of prediction results
    }

    // Step 4: Load category mappings from files
    // Method to load category mappings from a file
    public static Map<Integer, String> loadCategoryMap(String filename) throws IOException {
        Map<Integer, String> map = new HashMap<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            // Format for Map File is: categoryName,categoryNumber
            String[] parts = line.split(",");
            if (parts.length != 2) {
                System.err.println("Invalid format in mapping file: " + line);
                continue;
            }
            String category = parts[0];
            int number = Integer.parseInt(parts[1]);
            map.put(number, category); // Map the category number to the category name
        }
        br.close();
        return map; // Return the mapping
    }

    // Step 5: Find the highest-rated genre for each title type
    // Method to find the highest-rated genre per title type
    public static Map<Integer, PredictionResult> findHighestRatedGenres(List<PredictionResult> predictions) {
        Map<Integer, PredictionResult> highestRatedGenres = new HashMap<>();

        for (PredictionResult pr : predictions) {
            int titleTypeNumber = pr.getTitleTypeNumber();
            // Update the highest-rated genre if necessary
            if (!highestRatedGenres.containsKey(titleTypeNumber) ||
                highestRatedGenres.get(titleTypeNumber).getPredictedRating() < pr.getPredictedRating()) {
                highestRatedGenres.put(titleTypeNumber, pr);
            }
        }

        return highestRatedGenres; // Return the map of highest-rated genres
    }

    // Step 6: Display the results
    // Method to display the results to the console
    public static void displayResults(Map<Integer, PredictionResult> highestRatedGenres,
                                      Map<Integer, String> titleTypeMap,
                                      Map<Integer, String> genreMap) {
        System.out.println("Highest Rated Genres for 2025:");
        for (Map.Entry<Integer, PredictionResult> entry : highestRatedGenres.entrySet()) {
            int titleTypeNumber = entry.getKey();
            PredictionResult pr = entry.getValue();
            String titleType = titleTypeMap.get(titleTypeNumber); // Get the title type string from mapfile
            String genre = genreMap.get(pr.getGenreNumber());     // Get the genre string from mapfile
            double predictedRating = pr.getPredictedRating();

            System.out.println("Title Type: " + titleType +
                               ", Highest Rated Genre: " + genre +
                               ", Predicted Rating: " + String.format("%.2f", predictedRating));
        }
    }
    
}

//Class to help store prediction results
class PredictionResult {
    private int titleTypeNumber;
    private int genreNumber;
    private double predictedRating;

    public PredictionResult(int titleTypeNumber, int genreNumber, double predictedRating) {
        this.titleTypeNumber = titleTypeNumber;
        this.genreNumber = genreNumber;
        this.predictedRating = predictedRating;
    }

    public int getTitleTypeNumber() { return titleTypeNumber; }
    public int getGenreNumber() { return genreNumber; }
    public double getPredictedRating() { return predictedRating; }
}
