Finds runtime in 30 minute intervals bound to title type and genre, associates with average rating, weighted average rating, average runtime, total votes, and count of occurances

Input must be the output of RawDataCombiner_Filtered

Input Command: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Sample Output: "under30/short/Musical   avgRating=6.78,weightedAvgRating=6.52,avgRuntime=12.8,totalVotes=98573,count=1398"