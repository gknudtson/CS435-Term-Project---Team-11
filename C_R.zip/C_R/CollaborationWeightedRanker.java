import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.input.KeyValueTextInputFormat;
import org.apache.log4j.Logger;

import java.io.IOException;

public class CollaborationWeightedRanker {
    private static final Logger logger = Logger.getLogger(CollaborationWeightedRanker.class);

    public static class WeightMapper extends Mapper<Text, Text, DoubleWritable, Text> {
        private DoubleWritable weightedRating = new DoubleWritable();
        
        private static final double COLLAB_WEIGHT = 0.4;
        private static final double VOTES_WEIGHT = 0.3;
        private static final double TIME_WEIGHT = 0.2;
        private static final double CONSISTENCY_WEIGHT = 0.1;
        private static final double AVG_GENRE_VOTES = 10000.0;
        
        public void map(Text key, Text value, Context context) 
                throws IOException, InterruptedException {
            try {
                String[] metrics = value.toString().split(",");
                double avgRating = 0.0;
                long totalVotes = 0;
                int collaborations = 0;
                double highestRating = 0.0;
                double lowestRating = 10.0;
                int duration = 0;

                for (String metric : metrics) {
                    String[] parts = metric.split("=");
                    if (parts.length == 2) {
                        switch (parts[0]) {
                            case "avgRating":
                                avgRating = Double.parseDouble(parts[1]);
                                break;
                            case "totalVotes":
                                totalVotes = Long.parseLong(parts[1]);
                                break;
                            case "collaborations":
                                collaborations = Integer.parseInt(parts[1]);
                                break;
                            case "highestRating":
                                highestRating = Double.parseDouble(parts[1]);
                                break;
                            case "lowestRating":
                                lowestRating = Double.parseDouble(parts[1]);
                                break;
                            case "duration":
                                duration = Integer.parseInt(parts[1]);
                                break;
                        }
                    }
                }

                double collaborationFactor = Math.log(collaborations + 1) * COLLAB_WEIGHT;
                double votesFactor = Math.log(totalVotes/AVG_GENRE_VOTES + 1) * VOTES_WEIGHT;
                double timeFactor = (Math.min(duration, 10) / 10.0) * TIME_WEIGHT;
                double consistencyFactor = ((10 - (highestRating - lowestRating)) / 10.0) * CONSISTENCY_WEIGHT;

                double weightedAvg = avgRating * (collaborationFactor + votesFactor + timeFactor + consistencyFactor);

                String outputValue = String.format("%s\t%s\t" +
                    "collaborationScore=%.2f\t" +
                    "voteScore=%.2f\t" +
                    "timeScore=%.2f\t" +
                    "consistencyScore=%.2f",
                    key.toString(),
                    value.toString(),
                    collaborationFactor,
                    votesFactor,
                    timeFactor,
                    consistencyFactor
                );

                weightedRating.set(-weightedAvg);
                context.write(weightedRating, new Text(outputValue));
                
            } catch (NumberFormatException e) {
                //logger.warn("Error parsing numbers from line: " + value.toString());
            }
        }
    }

    public static class WeightReducer extends Reducer<DoubleWritable, Text, Text, Text> {
        public void reduce(DoubleWritable key, Iterable<Text> values, Context context) 
                throws IOException, InterruptedException {
            double actualWeightedRating = -key.get();
            
            for (Text value : values) {
                String[] parts = value.toString().split("\t");
                if (parts.length >= 2) {
                    String outputKey = String.format("%.2f", actualWeightedRating);

                    StringBuilder outputValue = new StringBuilder();
                    outputValue.append(parts[0]); 
                    outputValue.append("\t");
                    outputValue.append("Original metrics: ").append(parts[1]);
                    outputValue.append("\t");
                    outputValue.append("Factor scores: ");
                    for (int i = 2; i < parts.length; i++) {
                        outputValue.append(parts[i]).append(", ");
                    }
                    
                    context.write(new Text(outputKey), new Text(outputValue.toString().trim()));
                }
            }
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: CollaborationWeightedRanker <input path> <output path>");
            System.exit(-1);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Collaboration Weighted Ranking");
        job.setJarByClass(CollaborationWeightedRanker.class);

        job.setInputFormatClass(KeyValueTextInputFormat.class);

        job.setMapperClass(WeightMapper.class);
        job.setReducerClass(WeightReducer.class);

        job.setMapOutputKeyClass(DoubleWritable.class);
        job.setMapOutputValueClass(Text.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(Text.class);

        job.setNumReduceTasks(1);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}