import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.JFrame;
import java.io.*;
import java.util.*;

public class RatingVsYearPlot extends JFrame {

    public RatingVsYearPlot(String title, String chartTitle, XYSeriesCollection ratingDataset, XYSeriesCollection weightDataset, double maxWeight) {
        super(title);

        // Create the chart with average rating axis
        JFreeChart chart = ChartFactory.createXYLineChart(
                chartTitle,
                "Year",
                "Average Rating",
                ratingDataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        XYPlot plot = chart.getXYPlot();

        // Set the range for the average rating axis (primary y-axis)
        NumberAxis ratingAxis = (NumberAxis) plot.getRangeAxis();
        ratingAxis.setRange(0, 10);

        // Set up the secondary axis for weight and apply calculated Weight
        NumberAxis weightAxis = new NumberAxis("Weight");
        weightAxis.setRange(0, maxWeight + maxWeight * 0.1);
        plot.setRangeAxis(1, weightAxis);
        plot.setDataset(1, weightDataset);
        plot.mapDatasetToRangeAxis(1, 1);

        // Renderer for primary (rating) and secondary (weight) datasets
        XYLineAndShapeRenderer ratingRenderer = new XYLineAndShapeRenderer();
        plot.setRenderer(0, ratingRenderer);

        XYLineAndShapeRenderer weightRenderer = new XYLineAndShapeRenderer(true, false);
        plot.setRenderer(1, weightRenderer); 

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        setContentPane(chartPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) throws IOException {
        if (args.length != 2) {
            System.out.println("Usage: java RatingVsYearPlot <TitleType> <Genre>");
            return;
        }

        String titleTypeStr = args[0];
        String genreStr = args[1];

        Map<String, Integer> titleTypeMap = loadMapping("titleTypeMap.txt");
        Map<String, Integer> genreMap = loadMapping("genreMap.txt");

        if (!titleTypeMap.containsKey(titleTypeStr) || !genreMap.containsKey(genreStr)) {
            System.out.println("Invalid TitleType or Genre specified.");
            return;
        }

        int titleType = titleTypeMap.get(titleTypeStr);
        int genre = genreMap.get(genreStr);

        // Load data
        List<DataPoint> dataPoints = loadData("data.csv", titleType, genre);

        if (dataPoints.isEmpty()) {
            System.out.println("No data found for the specified TitleType and Genre.");
            return;
        }

        // Create series for rating and weight
        XYSeries ratingSeries = new XYSeries("Rating vs Year for " + titleTypeStr + " - " + genreStr);
        XYSeries weightSeries = new XYSeries("Weight vs Year for " + titleTypeStr + " - " + genreStr);

        double maxWeight = 0;
        for (DataPoint dp : dataPoints) {
            ratingSeries.add(dp.year, dp.rating);

            // Calculate weight and track maximum value for scaling
            double voteWeight = Math.log(dp.totalVotes);
            double countWeight = Math.log(dp.count);
            double weight = voteWeight * countWeight;
            weightSeries.add(dp.year, weight);

            if (weight > maxWeight) {
                maxWeight = weight;
            }
        }

        // Create datasets for rating and weight
        XYSeriesCollection ratingDataset = new XYSeriesCollection();
        ratingDataset.addSeries(ratingSeries);

        XYSeriesCollection weightDataset = new XYSeriesCollection();
        weightDataset.addSeries(weightSeries);

        // Create and display the chart
        RatingVsYearPlot chart = new RatingVsYearPlot(
                "Rating vs Weight Over Years",
                "Average Rating and Weight vs Year for " + titleTypeStr + " - " + genreStr,
                ratingDataset, weightDataset, maxWeight
        );

        chart.pack();
        chart.setVisible(true);
    }

    // Method to load data from CSV based on title type and genre
    public static List<DataPoint> loadData(String filename, int titleType, int genre) throws IOException {
        List<DataPoint> dataPoints = new ArrayList<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        br.readLine(); // Skip header row

        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length < 6) {
                System.err.println("Invalid data format in line: " + line);
                continue;
            }

            int fileTitleType = Integer.parseInt(parts[1]);
            int fileGenre = Integer.parseInt(parts[2]);
            int year = Integer.parseInt(parts[0]);
            year = year > 1000 ? year : Integer.parseInt(parts[0].replaceAll("[^0-9]", "")); // Fix year formatting
            double rating = Double.parseDouble(parts[3]);
            int totalVotes = Integer.parseInt(parts[4]);
            int count = Integer.parseInt(parts[5]);

            if (fileTitleType == titleType && fileGenre == genre) {
                dataPoints.add(new DataPoint(year, rating, totalVotes, count));
            }
        }
        br.close();

        return dataPoints;
    }

    // Method to load mappings from a text file
    public static Map<String, Integer> loadMapping(String filename) throws IOException {
        Map<String, Integer> map = new HashMap<>();
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;

        while ((line = br.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length != 2) {
                System.err.println("Invalid mapping format in line: " + line);
                continue;
            }

            String key = parts[0].trim();
            int value = Integer.parseInt(parts[1].trim());
            map.put(key, value);
        }
        br.close();

        return map;
    }

    // Helper class to store data points
    static class DataPoint {
        int year;
        double rating;
        int totalVotes;
        int count;

        public DataPoint(int year, double rating, int totalVotes, int count) {
            this.year = year;
            this.rating = rating;
            this.totalVotes = totalVotes;
            this.count = count;
        }
    }
}
