Finds director/writer pairings and associates thme with average ratings, total votes, and the amount of collaborations together
Input must be the output of RawDataCombiner_Filtered

Input Command: hadoop jar <jar_name> <.class of driver> <HDFSFilteredDataOutputPath> <HDFSOutputPath>

Sample output: "Action/nm0005204/nm2785236      avgRating=8.00,totalVotes=66901,collaborations=2,highestRating=8.0,lowestRating=8.0,yearSpan=2012-2023,duration=12"