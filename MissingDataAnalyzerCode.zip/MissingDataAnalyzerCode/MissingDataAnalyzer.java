import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class MissingDataAnalyzer {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: MissingDataAnalyzer <inputFilePath> <outputFilePath>");
            return;
        }

        String inputFilePath = args[0];
        String outputFilePath = args[1];
        Map<String, Integer> missingCounts = new LinkedHashMap<>();
        int totalRows = 0;

        try {
            Configuration conf = new Configuration();
            FileSystem fs = FileSystem.get(conf);
            Path inputPath = new Path(inputFilePath);

            BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(inputPath)));
            // Read First Line as Header
            String headerLine = br.readLine();
            if (headerLine == null) {
                System.out.println("Input file is empty or missing.");
                return;
            }

            // Split header into categories and initialize missingCounts map
            String[] categories = headerLine.split("\t");
            for (String category : categories) {
                missingCounts.put(category, 0);
            }

            // Process each row
            String line;
            while ((line = br.readLine()) != null) {
                totalRows++;
                String[] values = line.split("\t");

                // Count \N occurrences per column
                for (int i = 0; i < values.length; i++) {
                    if (values[i].equals("\\N") && !categories[i].equals("tconst")) {
                        missingCounts.put(categories[i], missingCounts.get(categories[i]) + 1);
                    }
                }
            }
            br.close();

            Path outputPath = new Path(outputFilePath + "/missing_data_report.txt");
            BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fs.create(outputPath, true)));

            // Write the header for output first then percentages
            bw.write(String.format("%-20s %s%n", "Category", "Percentage Missing"));
            for (String category : missingCounts.keySet()) {
                double missingPercentage = (double) missingCounts.get(category) / totalRows * 100;
                bw.write(String.format("%-20s %.2f%%%n", category, missingPercentage));
            }
            bw.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
