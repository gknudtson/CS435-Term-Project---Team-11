Code Outputs to Terminal the Predicted Genre and Rating for each TitleType

MUST HAVES in Directory with jar and java files
part-r-00000 from GenreRevised Output renamed as data.csv
titleTypeMap-r-00000 from GenreRevised Output renamed titleTypeMap.txt
genreMap-r-00000 from GenreRevised Output reformated to genreMap using the formatGenreMap.sh then renamed to genreMap.txt


Compile using:
javac -cp .:weka.jar GenreRatingPredictor.java

Run using:
java -cp .:weka.jar GenreRatingPredictor

