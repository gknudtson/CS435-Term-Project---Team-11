Input File needs to be rows of data seperated by tabs with the first row being headers seperated by tabs

hadoop jar <JarFile> MissingDataAnalyzer <HDFSInputFilePath> <HDFSOutputFilePath>

